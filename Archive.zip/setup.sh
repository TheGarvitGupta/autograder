#!/usr/bin/env bash

apt-get install -y python python-pip python-dev
pip3 install sh
pip install sh
# pip install -r /autograder/source/requirements.txt